
// HideText.java
// Andrew Davison, May 2009, ad@fivedots.coe.psu.ac.th

/* A test rig for the steganography hide() method which hides 
   a text file in a PNG file, creating a new image whose name
   ends with ...Msg.png

   Depending on the steg type number supplied by the user, 
   one of four possible steganography classes is used.
     0 == Steganography class
     1 == StegCrypt class
     2 == MultiStegCrypt class
     3 == FragMultiStegCrypt class

   Usage: run HideText <steg type number> <text file> <PNG file>
   e.g.
     run HideText 3 examps\Comparison.java  images\waterlilies.png
            // generates images\waterliliesMsg.png  using FragMultiStegCrypt
*/
package esteganografiajava;

public class HideText{

    public HideText(int stegType,String texto,
            String imagen) {
        switch(stegType) {
        case 1:
          System.out.println("Using StegCrypt...");
          StegCrypt.hide(texto, imagen);
          break;
        case 2:
          System.out.println("Using MultiStegCrypt...");
          MultiStegCrypt.hide(texto, imagen);
          break;
        case 3:
          System.out.println("Using FragMultiStegCrypt...");
          FragMultiStegCrypt.hide(texto, imagen);
          break;
        default:
          System.out.println("Using basic Steganography...");
          //Steganography.hide(args[1], args[2]);
          break;
      } // end switch
    }
    
  
  private static int getNumber(String str)
  {
    int val = 0;
    try { 
      val = Integer.parseInt(str); 
    } 
    catch (NumberFormatException e)
    { System.out.println("Could not parse number: \"" + str + "\""); }

    return val;
  }  // end of getNumber()


}  // end of HideText class