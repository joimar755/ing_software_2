
// RevealText.java
// Andrew Davison, May 2009, ad@fivedots.coe.psu.ac.th

/* A test rig for the steganography reveal() method which extracts 
   a message from a PNG file, creating a new text file.

   Depending on the steg type number supplied by the user, 
   one of four possible steganography classes is used.
     0 == Steganography class
     1 == StegCrypt class
     2 == MultiStegCrypt class
     3 == FragMultiStegCrypt class

   Usage: RevealText <steg type number> <PNG file>
   e.g.
     run RevealText 3 images\waterlilliesMsg.png
       // generates images\waterlilliesMsg.txt  using FragMultiStegCrypt

*/
package esteganografiajava;

public class RevealText
{

    public RevealText(int stegType, String imagen) {
        switch(stegType) {
        case 1:
          System.out.println("Using StegCrypt...");
          StegCrypt.reveal(imagen);
          break;
        case 2:
          System.out.println("Using MultiStegCrypt...");
          MultiStegCrypt.reveal(imagen);
          break;
        case 3:
          System.out.println("Using FragMultiStegCrypt...");
          FragMultiStegCrypt.reveal(imagen);
          break;
        default:
          System.out.println("Using basic Steganography...");
          //Steganography.reveal(imagen);
          break;
      } // end switch
    }
   
}  // end of RevealText class