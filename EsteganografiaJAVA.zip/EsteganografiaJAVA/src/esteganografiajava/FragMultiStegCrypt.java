 
// FragMultiStegCrypt.java
// Andrew Davison, May 2009, ad@fivedots.coe.psu.ac.th

/* A steganography class for hiding text inside a PNG image, and for
   extracting the text later.  

   The class has two public static methods:

        * boolean hide(String textFnm, String imFnm)
              // the modified image is stored in <imFnm>Msg.png

        * boolean reveal(String imFnm)
              // the extracted message is stored in <imFnm>.txt


   This class is an extension of the Steganongraphy class to include a password
   for encrypting the binary version of the plain-text message, and to store
   multiple copies of the stego message (stego for short), separated into fragments.

   Each stego fragment has 5 fields:

      "XXX"   <fragment number>   <password> 
      <size of encrypted binary message fragment> 
      <encrypted binary message fragment>

   The stego is spread out over the image's bytes by modifying each byte's
   right most bit (the least significant bit, LSB). So 1 byte of stego data requires
   the modification of 8 bytes of the image (i.e. 1 stego data bit is stored in 
   1 image byte).

   The stego fragments are added as many times as the entire stego 
   will fit into the LSBs of the image's bytes.

   More details on the stego's fields:

     "XXX" is the stego fragment header.

     The fragment number can range between 0-99 (NUM_FRAGS-1), which is encoded
     as a string of 2 characters, which requires 2*8 bytes in the image.

     The password is a 3-letter randomly generated string, which requires 
     3*8 bytes in the image. Each message fragment has its own password.

     The message fragment size is a Java integer (i.e. 4 bytes long),
     which requires 4*8 bytes in the image.

     A message fragment is encrypted, with each byte requiring 8 bytes 
     of storage in the image.


   The encryption and decryption of byte arrays is done using 
   Jasypt's BasicBinaryEncryptor
   Jasypt is available at http://www.jasypt.org/

   reveal() searches through the image gathering stego fragments. If the
   image has been cropped then a given fragment may be incomplete. This
   won't stop the search, which will scan the entire image, and hopefully find
   missing fragments somewhere else. 

   The search stops either when all the stego fragments have been found, or the 
   end of file is reached.

   Even if some stego fragments are missing, the other fragments can be decrypted,
   and the partial text will be saved.


   ----------------------------------------

   Changed to message format from MultiStegCrypt:
      * stego header reduced:   "XXXXX" --> "XXX"    (2 bytes less)
      * added a fragment number field: 00-99      (using 2 bytes)
      * password field reduced:   10 chars --> 3 chars    (7 bytes less)

   Total header size reduced by 7 bytes

*/
package esteganografiajava;

import java.io.*;
import java.awt.*;
import java.util.*;
import java.awt.image.*;
import javax.imageio.*;

import org.jasypt.util.binary.*;



public class FragMultiStegCrypt
{
  private static final String STEGO_HEADER = "XXX";   // was "XXXXX"
  private static final int NUM_FRAG_LEN = 2;  
  private static final int PASSWORD_LEN = 3;          // was 10
  private static final int MAX_INT_LEN = 4;

  private static final int DATA_SIZE = 8;   
           // number of image bytes required to store one stego byte

  private static final int NUM_FRAGS = 100;    
      /* number of stego fragments for a message;
         100 means that at most 2 characters will be needed to store a fragment number as a string */


  private static Random rand = new Random();    // used for password generation

  private static int currMsgFragLen;   // assigned in extractMsgFrag(), used by findFragments()




  public static boolean hide(String textFnm, String imFnm)
  /* hide message read from textFnm inside image read from imFnm;
     the resulting image is stored in <inFnm>Msg.png */
  {
    // read in the message as a series of byte array fragments stored in an array
    byte[][] msgFrags = readByteFrags(textFnm); 
    if (msgFrags == null)
      return false;

    byte[][] stegoFrags = new byte[NUM_FRAGS][];   // holds the stego fragments

    for (int i=0; i < NUM_FRAGS; i++) {
      String password = genPassword();   // generate a password for each fragment
      byte[] passBytes = password.getBytes();

      // use the password to encrypt a message fragment
      byte[] encryptedFrag = encryptFrag(msgFrags[i], password);
      if (encryptedFrag == null)
        return false;

      // create the stego fragment
      stegoFrags[i] = buildStegoFrag(i, passBytes, encryptedFrag);
    }

    // access the image's data as a byte array
    BufferedImage im = loadImage(imFnm);
    if (im == null)
      return false;
    byte imBytes[] = accessBytes(im);

    if (!multipleHide(imBytes, stegoFrags))   // im is modified with multiple copies of the stego frags
      return false;

    // store the modified image in <fnm>Msg.png
    String fnm = getFileName(imFnm);
    return writeImageToFile( fnm + "Msg.png", im);
  }  // end of hide()



  private static byte[][] readByteFrags(String fnm)
  /* Read in fnm, returning it as NUM_FRAGS message fragments stored in an array.
     Each message fragment is a byte array. */
  {
    String inputText = readTextFile(fnm);
    if ((inputText == null) || (inputText.length() == 0))
      return null;

    // decide on fragment length
    int fragLen = inputText.length() / NUM_FRAGS;    // integer division
    System.out.println("Input text size: " + inputText.length() + 
                        "; fragment length: " + fragLen);

    if (fragLen == 0) {    // since text length < NUM_FRAGS
      inputText = String.format("%1$-" + NUM_FRAGS + "s", inputText);   
                // right pad the text with spaces so NUM_FRAGS long
      fragLen = 1;
    }

    // split the input text into multiple fragments (byte arrays)
    int startPosn = 0;
    int endPosn = fragLen;
    String textFrag;
    byte[][] msgFrags = new byte[NUM_FRAGS][];

    for(int i=0; i < NUM_FRAGS-1; i++) {
      textFrag = inputText.substring(startPosn, endPosn);    // cut out a fragment
      // System.out.println(i + ". textFrag: " + textFrag);
      msgFrags[i] = textFrag.getBytes();
      startPosn = endPosn;
      endPosn += fragLen;
    }

    textFrag = inputText.substring(startPosn);     // store remaining fragment of text
    // System.out.println((NUM_FRAGS-1) + ". textFrag: " + textFrag);
    msgFrags[NUM_FRAGS-1] = textFrag.getBytes();

    return msgFrags;
  }  // end of readByteFrags()



  private static String readTextFile(String fnm)
  // read in fnm, returning it as a single string
  {
    BufferedReader br = null;
    StringBuffer sb = new StringBuffer();
 
    try {
      br = new BufferedReader(new FileReader( new File(fnm) ));
      String text = null;
      while ((text = br.readLine()) != null)
        sb.append(text + "\n");
    } 
    catch (Exception e) {
      System.out.println("Could not completely read " + fnm);
      return null;
    } 
    finally {
      try {
        if (br != null)
          br.close();
       } 
       catch (IOException e) {
         System.out.println("Problem closing " + fnm);
         return null;
       } 
    }
    System.out.println("Read in " + fnm);
    return sb.toString();
  }  // end of readTextFile()
    



  private static String genPassword()
  // return a password of random characters of length PASSWORD_LEN
  {
    String availChars = "abcdefghjklmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789";   // chars available for password

    StringBuffer sb = new StringBuffer(PASSWORD_LEN);
    for (int i=0; i<PASSWORD_LEN; i++ ) { 
      int pos = rand.nextInt( availChars.length());
      sb.append( availChars.charAt(pos));
    }
    String password = sb.toString();
    // System.out.println("Password: \"" + password + "\"");
    return password;
  }  // end of genPassword()



  private static byte[] encryptFrag(byte[] msgFrag, String password)
  // encrypt a message fragment (a byte array) using the password
  {
    BasicBinaryEncryptor bbe = new BasicBinaryEncryptor();
    bbe.setPassword(password);
    byte[] encryptedFrag = bbe.encrypt(msgFrag);
    // System.out.println("Length of encrypted text file in bytes: " + encryptedFrag.length);

    return encryptedFrag;
  }  // end of encryptFrag()
  


  private static byte[] buildStegoFrag(int i, byte[] passBytes, byte[] encryptedFrag)
  /* Build a single steg fragment (a byte array), made up of 5 fields:
       "XXX"  <fragment number>   <password> 
       <size of encrypted binary message fragment> 
       <encrypted binary message fragment>
  */
  { // create three of the fields (as byte arrays)
    byte headerBytes[] = STEGO_HEADER.getBytes();    // "XXX"
    byte[] fragNumBs = fragNumberToBytes(i);
    byte[] lenBs = intToBytes(encryptedFrag.length);

    int totalLen = STEGO_HEADER.length() + fragNumBs.length + passBytes.length +
                   lenBs.length + encryptedFrag.length;
    byte[] sFrag = new byte[totalLen];    // for holding the resulting stego fragment

    // combine the five fields into one byte array
    // public static void arraycopy(Object src, int srcPos, Object dest, int destPos, int length);
    int destPos = 0;
    System.arraycopy(headerBytes, 0, sFrag, destPos, STEGO_HEADER.length());   // header
    destPos += STEGO_HEADER.length();
    System.arraycopy(fragNumBs, 0, sFrag, destPos, fragNumBs.length);        // fragment number
    destPos += fragNumBs.length;
    System.arraycopy(passBytes, 0, sFrag, destPos, passBytes.length);        // password
    destPos += passBytes.length;
    System.arraycopy(lenBs, 0, sFrag, destPos, lenBs.length);   // length of encrypted binary message
    destPos += lenBs.length;
    System.arraycopy(encryptedFrag, 0, sFrag, destPos, encryptedFrag.length);   // encrypted binary message

    // System.out.println("Num. pixels to store fragment " + i + ": " + totalLen*DATA_SIZE);
    return sFrag;
  }  // end of buildStegoFrag()


  
  private static byte[] fragNumberToBytes(int i)
  // convert fragment number to a NUM_FRAG_LEN-element byte array
  {
    String intStr = String.format("%" + NUM_FRAG_LEN + "d", i);  
    // System.out.println("Frag Number String: \"" + intStr + "\""); 
    byte[] fragNumBs = intStr.getBytes();
  
    return fragNumBs;
  }  // end of fragNumberToBytes()




  private static byte[] intToBytes(int i)
  // split integer i into a MAX_INT_LEN-element byte array
  {
    // map the parts of the integer to a byte array
    byte[] integerBs = new byte[MAX_INT_LEN];
    integerBs[0] = (byte) ((i >>> 24) & 0xFF);
    integerBs[1] = (byte) ((i >>> 16) & 0xFF);
    integerBs[2] = (byte) ((i >>> 8) & 0xFF);
    integerBs[3] = (byte) (i & 0xFF);

    // for (int j=0; j < integerBs.length; j++)
    //  System.out.println(" integerBs[ " + j + "]: " + integerBs[j]);

    return integerBs;
  }  // end of intToBytes()



  private static BufferedImage loadImage(String imFnm)
  // read the image from the imFnm file
  {
    BufferedImage im = null;
    try {
      im = ImageIO.read( new File(imFnm) );
      System.out.println("Read " + imFnm);
    } 
    catch (IOException e) 
    { System.out.println("Could not read image from " + imFnm);  }

    return im;
  }   // end of loadImage()



  private static byte[] accessBytes(BufferedImage image)
  // access the data bytes of the image
  {
    WritableRaster raster = image.getRaster();
    DataBufferByte buffer = (DataBufferByte) raster.getDataBuffer();
    return buffer.getData();
  }  // end of accessBytes()



  private static boolean multipleHide(byte[] imBytes, byte[][] stegoFrags)
  // store the stego fragments multiple times in the image 
  {
    int imLen = imBytes.length;
    System.out.println("Byte length of image: " + imLen);

    // calculate total length of all the stego fragments
    int totalLen = 0;
    for(int i=0; i < NUM_FRAGS; i++)
      totalLen += stegoFrags[i].length;
    System.out.println("Total byte length of info: " + totalLen);

    // check that the stego will fit into the image
    // multiply stego length by number of image bytes required to store one stego byte
    if ((totalLen*DATA_SIZE) > imLen) {
      System.out.println("Image not big enough for message");
      return false;
    }

    // calculate the number of times the complete stego can be hidden
    int numHides = imLen/(totalLen*DATA_SIZE);   // integer division, so only approximate
    System.out.println("No. of message duplications: " + numHides);

    int offset = 0;
    for(int h=0; h < numHides; h++)    // hide all fragments, numHides times
      for(int i=0; i < NUM_FRAGS; i++) { 
        hideStegoFrag(imBytes, stegoFrags[i], offset);
        offset += stegoFrags[i].length*DATA_SIZE;
      }

    return true;
  }  // end of multipleHide()
    


  private static void hideStegoFrag(byte[] imBytes, byte[] stegoFrag, int offset)
  // store stego fragment in image starting at byte posn offset
  {
    for (int i = 0; i < stegoFrag.length; i++) {       // loop through stego fragment
      int byteVal = stegoFrag[i];
      for(int j=7; j >= 0; j--) {    // loop through the 8 bits of each stego byte
        int bitVal = (byteVal >>> j) & 1;

        // change last bit of image byte to be the stego bit
        imBytes[offset] = (byte)((imBytes[offset] & 0xFE) | bitVal);
        offset++;
      }
    }
  }  // end of hideStegoFrag()
    



  private static String getFileName(String fnm)
  // extract the name from the filename without its suffix
  {
    int extPosn = fnm.lastIndexOf('.');
    if (extPosn == -1) {
      System.out.println("No extension found for " + fnm);
      return fnm;   // use the original file name
    }

    return fnm.substring(0, extPosn);
  }  // end of getFileName()



  private static boolean writeImageToFile(String outFnm, BufferedImage im)
  // save the im image in a PNG file called outFnm
  {
    if (!canOverWrite(outFnm))
      return false;

    try {
      ImageIO.write(im, "png", new File(outFnm));
      System.out.println("Image written to PNG file: " + outFnm);
      return true;
    } 
    catch(IOException e)
    { System.out.println("Could not write image to " + outFnm); 
      return false;
    }
  } // end of writeImageToFile();



  private static boolean canOverWrite(String fnm)
  /* If fnm already exists, get a response from the
     user about whether it should be overwritten or not. */
  {
    File f = new File(fnm);
    if (!f.exists())
      return true;     // can overewrite since the file is new

    // prompt the user about whether the file can be overwritten 
    Scanner in = new Scanner(System.in);
    String response;
    System.out.print("File " + fnm + " already exists. ");
    while (true) {
      System.out.print("Overwrite (y|n)? ");
      response = in.nextLine().trim().toLowerCase();
      if (response.startsWith("n"))  // no
        return false;
      else if (response.startsWith("y"))  // yes
        return true;
    }
  }  // end of canOverWrite()



  // --------------------------- reveal a message -----------------------------------


  public static boolean reveal(String imFnm)
  /* Retrieve the hidden message from imFnm. Search for the stego fragments,
     and keep trying until all of them have been found, or the end of the file is
     reached  */
  {
    // access the image's data as a byte array
    BufferedImage im = loadImage(imFnm);
    if (im == null)
      return false;
    byte[] imBytes = accessBytes(im);

    String[] msgFrags = new String[NUM_FRAGS];    // holds the message fragments
    int numFragsFound = findFragments(imBytes, msgFrags);
    if (numFragsFound == 0) {
      System.out.println("No message found");
      return false;
    }

    String msg = combineFragments(msgFrags, numFragsFound);
    String fnm = getFileName(imFnm);
    return writeStringToFile(fnm + ".txt", msg);  // save message in a text file
  }  // end of reveal()



  private static int findFragments(byte[] imBytes, String[] msgFrags)
  // retrieve the message fragments from the image; return the number of fragments found
  {
    for(int i=0; i < NUM_FRAGS; i++)
      msgFrags[i] = null;

    int imLen = imBytes.length;
    System.out.println("Byte Length of image: " + imLen);

    int numFragsFound = 0;

    int headOffset = STEGO_HEADER.length()*DATA_SIZE;   // stego header space used in image
    int fragNumOffset = NUM_FRAG_LEN*DATA_SIZE;         // fragment number space used in image
    
    int i = 0;
    while ((i < imLen) && (numFragsFound < NUM_FRAGS)) {
      if (!findHeader(imBytes, i))   // no stego header found at pos i
        i++;  // move on
      else {   // found header
        i += headOffset;    // move past stego header
        int fNum = findFragNumber(imBytes, i); 
        if (fNum != -1) {    // found a fragment number
          i+= fragNumOffset;    // move past fragment number
          if (msgFrags[fNum] != null)     // we already have a message for this fragment
            System.out.println("Fragment " + fNum + " already extracted");
          else {   // this is a fragment we haven't seen before
            // System.out.println("Trying to extract fragment " + fNum);
            String msgFrag = extractMsgFrag(imBytes, i);
            if (msgFrag == null) 
              System.out.println("Failed to extract fragment " + fNum);
            else {    // got the message fragment
              System.out.println("Storing fragment " + fNum);
              msgFrags[fNum] = msgFrag;
              numFragsFound++;
              i += (PASSWORD_LEN + MAX_INT_LEN + currMsgFragLen)*DATA_SIZE;  
                  /* move past past password, length & message fragment; 
                     currMsgFragLen is assigned in extractMsgFrag()   */
            }
          }
        }
      }
    }
    return numFragsFound;
  }  // end of findFragments()



  private static boolean findHeader(byte[] imBytes, int offset)
  // does a stego header start at the offset position in the image?
  {
    byte[] headerBytes = extractHiddenBytes(imBytes, STEGO_HEADER.length(), offset);
    if (headerBytes == null)
      return false;
 
    String header = new String(headerBytes);
    if (!header.equals(STEGO_HEADER))
      return false;

    // System.out.println("Found stego header at " + offset);
    return true;
  }  // end of findHeader()
  


  private static int findFragNumber(byte[] imBytes, int offset)
  // extract a fragment number, which should be in the range 0-(NUM_FRAGS-1)
  {
    byte[] fNumBytes = extractHiddenBytes(imBytes, NUM_FRAG_LEN, offset);
    if (fNumBytes == null)
      return -1;
 
    // convert the fragment number bytes into an integer
    String fNumStr = new String(fNumBytes).trim();
    int fNum = -1;
    try { 
      fNum = Integer.parseInt(fNumStr); 
    } 
    catch (NumberFormatException e)
    { System.out.println("Could not parse fragment number: \"" + fNumStr + "\""); }

    if ((fNum < 0) || (fNum >= NUM_FRAGS)){
      System.out.println("Incorrect fragment number");
      return -1;
    }
    // System.out.println("Found fragment number: " + fNum);
    return fNum;
  }  // end of findFragNumber()




  private static String extractMsgFrag(byte[] imBytes, int offset)
  /* retrieve hidden message fragment from the image by extracting its password and
     the encrypted binary message fragment length, and using them to build the message 
     fragment.
     Assigns the message length to the global variable currMsgFragLen
   */
  {
    String password = getPassword(imBytes, offset);
    if (password == null)
      return null;

    offset += PASSWORD_LEN*DATA_SIZE;   // move past password
    int msgFragLen = getMsgFragLength(imBytes, offset);   // get the encrypted message fragment length 
    if (msgFragLen == -1)
      return null;
        
    currMsgFragLen = msgFragLen;  // used by findFragments()

    offset += MAX_INT_LEN*DATA_SIZE;   // move past message length
    return getMessageFrag(imBytes, msgFragLen, password, offset);
  }  // end of extractMsgFrag()



  private static String getPassword(byte[] imBytes, int offset)
  // extract the password from the image
  {
    byte[] passBytes = extractHiddenBytes(imBytes, PASSWORD_LEN, offset);
    if (passBytes == null)
      return null;
    String password = new String(passBytes);

    // check the password is all characters
    if (isPrintable(password)) {
    // System.out.println("Found password: \"" + password + "\"");
      return password;
    }
    else
      return null;
  }  // end of getPassword()




  private static int getMsgFragLength(byte[] imBytes, int offset)
  // retrieve encrypted binary message fragment length from the image
  {
    byte[] lenBytes = extractHiddenBytes(imBytes, MAX_INT_LEN, offset);
              // get the binary message fragment length as a byte array
    if (lenBytes == null)
      return -1;

    // for (int j=0; j < lenBytes.length; j++)
    //  System.out.println(" lenBytes[ " + j + "]: " + lenBytes[j]);

    // convert the byte array into an integer
    int msgFragLen = ((lenBytes[0] & 0xff) << 24) | 
                     ((lenBytes[1] & 0xff) << 16) | 
                     ((lenBytes[2] & 0xff) << 8) | 
                      (lenBytes[3] & 0xff);
    // System.out.println("Message fragment length: " + msgFragLen);

    if ((msgFragLen <= 0) || (msgFragLen > imBytes.length))  {
      System.out.println("Incorrect message length");
      return -1;
    }
    // else
    //  System.out.println("Revealed encrypted message length: " + msgFragLen);

    return msgFragLen;
  }  // end of getMsgFragLength()



  private static String getMessageFrag(byte[] imBytes, int msgFragLen, String password, int offset)
  /* Return a message fragment. First extract an encrypted binary message fragment
     of size msgFragLen from the image, decrypt it with the password, and 
     convert it to a string 
  */
  {
    byte[] enMsgFragBytes = extractHiddenBytes(imBytes, msgFragLen, offset); 
           // the encrypted message fragment is msgFragLen bytes long
    if (enMsgFragBytes == null)
      return null;

    // decrypt the fragment using the password    
    BasicBinaryEncryptor bbe = new BasicBinaryEncryptor();
    bbe.setPassword(password);
    byte[] msgFragBytes = null;
    try {
      msgFragBytes = bbe.decrypt(enMsgFragBytes);
      // System.out.println("Decrypted message length: " + msgFragBytes.length);
    }
    catch(Exception e)   // in case the decryption fails
    { System.out.println("Problem decrypting message fragment");
      return null;
    }

    String msgFrag = new String(msgFragBytes);

    // check the message fragment is all characters
    if (isPrintable(msgFrag)) {
    // System.out.println("Found message fragment: \"" + msgFrag + "\"");
      return msgFrag;
    }
    else
      return null;
  }  // end of getMessageFrag()




  private static byte[] extractHiddenBytes(byte[] imBytes, int size, int offset)
  // extract 'size' hidden data bytes, starting from 'offset' in the image bytes
  {
    int finalPosn = offset + (size*DATA_SIZE);
    if (finalPosn > imBytes.length) {
      System.out.println("End of image reached");
      return null;
    }

    byte[] hiddenBytes = new byte[size];

    for (int j = 0; j < size; j++) {    // loop through each hidden byte
      for (int i=0; i < DATA_SIZE; i++) {   // make one hidden byte from DATA_SIZE image bytes
        hiddenBytes[j] = (byte) ((hiddenBytes[j] << 1) | (imBytes[offset] & 1));   
                             // shift existing 1 left; store right most bit of image byte
        offset++;
      }
    }
    return hiddenBytes;
  }  // end of extractHiddenBytes()



  private static boolean isPrintable(String str)
  // is the string printable?
  {
    for (int i=0; i < str.length(); i++)
      if (!isPrintable(str.charAt(i))) {
        System.out.println("Unprintable character found");
        return false;
      }
    return true;
  }  // end of isPrintable()



  private static boolean isPrintable(int ch)
  // is ch a 7-bit ASCII character that could (sensibly) be printed?
  {
    if (Character.isWhitespace(ch) && (ch < 127))  // whitespace, 7-bit
      return true;
    else if ((ch > 32) && (ch < 127))
      return true;

    return false;
  }  // end of isPrintable()



  private static String combineFragments(String[] msgFrags, int numFragsFound)
  // combine all the message fragments into a single string
  {
    if (numFragsFound == NUM_FRAGS)
      System.out.println("ALL message fragments extracted");
    else
      System.out.println("Only found " + numFragsFound + "/" + NUM_FRAGS + " message fragments");

    StringBuffer sb = new StringBuffer();
    for (int i=0; i < NUM_FRAGS; i++) {
      if (msgFrags[i] != null)
        sb.append(msgFrags[i]);
      else
        sb.append("\n????? missing fragment " + i + " ?????");   // used when there's no fragment
    }
    return sb.toString();
  }  // end of combineFragments()



  private static boolean writeStringToFile(String outFnm, String msgStr)
  // write the message string into the outFnm text file
  {
    if (!canOverWrite(outFnm))
      return false;

    try {
      FileWriter out = new FileWriter( new File(outFnm) );
      out.write(msgStr);
      out.close();
      System.out.println("Message written to " + outFnm);
      return true;
    }
    catch(IOException e)
    {  System.out.println("Could not write message to " + outFnm);  
       return false;
    }
  }  // end of writeStringToFile()



}  // end of FragMultiStegCrypt class
